from django.shortcuts import render
from django.http import HttpResponse, request


# Create your views here.
def home(request):
    #return HttpResponse("<h1>Hello</h1>")
    return render(request, 'home.html',{'name':'Python'})