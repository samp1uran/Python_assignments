# IMPORTING
from flask import Flask, render_template, request, redirect, url_for

# INTRACTING
web = Flask(__name__)


# MAPPING for the home and register page
@web.route('/')
@web.route('/register')
def reg():
    # This function now correctly handles the '/register' route
    return render_template('register.html')


# MAPPING for the login page
@web.route('/login')
def login():
    # --- FIX 1 ---
    # Added a function for the '/login' route.
    # We'll assume you have a 'login.html' file.
    return render_template('login.html')


# MAPPING for the confirmation page
@web.route('/confirmation', methods=['POST', 'GET'])
def confirmation():  # --- FIX 5 (Bonus) --- Renamed function to be clear

    # --- FIX 4 --- Check for 'POST' (uppercase)
    if request.method == 'POST':
        # --- FIX 3 --- Use .get() with parentheses
        n = request.form.get('name')
        c = request.form.get('city')
        p = request.form.get('phone_number')

        return render_template('confirm.html', name=n, city=c, phone_number=p)

    # --- FIX 2 --- Added a return for GET requests
    # If a user just tries to visit /confirmation directly,
    # send them back to the register page.
    return redirect(url_for('reg'))


# MAIN
if __name__ == "__main__":
    web.run(debug=True)